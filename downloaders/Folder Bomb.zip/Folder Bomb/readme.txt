Folder bomb

put the folder bomb.bat where you want
and run the file to put the files in the location
and it might be on the desktop or where you put
the folder bomb


Please dont do this
_________________________________________________
1: Do not do this on bad computers
   it might crash them

2: Dont go doing this on other computers
unless they are fine with it